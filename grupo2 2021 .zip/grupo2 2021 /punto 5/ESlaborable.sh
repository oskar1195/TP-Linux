#!/bin/bash

read -p "Ingrese DIA, MES y ANIO en formato MM/DD/AAAA:" DATE
date "+%m-%d-%Y" -d "${DATE}" > /dev/null  2>&1
if [ $? != 0 ];
then
    echo La fecha "${DATE}" NO es un formato valido
    exit 1
fi

esLaborable(){
DIASEMANA=$(date -d "$DATE" +'%A')

if [[ "$DIA_SEMANA" == "SATURDAY" ]] || [[ "$DIA_SEMANA" == "SUNDAY" ]]; 
 then echo "NO SE LABURA" 
fi

Y=$(date -d "${DATE}" +'%Y')
FERIADO1="06/17/$Y"
FERIADO_DIA=$(date -d "$FERIADO1" +'%A')

if [ "$FERIADO_DIA" == "TUESDAY" ];
    then 
    FERIADO_NUEVO="$(date --date="$FERIADO1 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA" == "WEDNESDAY" ];
    then
    FERIADO_NUEVO1="$(date --date="$FERIADO1 -9days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO1" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA" == "THURSDAY" ];
    then 
    FERIADO_NUEVO2="$(date --date="$FERIADO_NUEVO1 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO2" ];
        then 
            echo "ES OTRO FERIADO"
        fi
fi
if [ "$FERIADO_DIA" == "FRIDAY" ];
    then 
    FERIADO_NUEVO3="$(date --date="$FERIADO1 +3days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO3" ];
        then 
            echo "TAMBIEN ES FERIADO"
        fi
fi
FERIADO2="08/17/$Y"
FERIADO_DIA2=$(date -d "$FERIADOT2" +'%A')

if [ "$FERIADO_DIA2" == "TUESDAY" ];
    then 
    FERIRADO_NUEVO4="$(date --date="$FERIADO2 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO4" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA2" == "WEDNESDAY" ];
    then
    FERIADO_NUEVO5="$(date --date="$FERIADO_2 -9days" +%m/%d/%Y)" 
        if [ "$DATE" == "$FERIADO_NUEVO5" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA2" == "THURSDAY" ];
    then 
    FERIADO_NUEVO6="$(date  --date="$FERIADOT2 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO6" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA2" == "FRIDAY" ];
    then 
    FERIADO_NUEVO7="$(date --date="$FERIADO_2 +3days" +%m/%d/%Y)"
        if [ "$DATE" = "$FERIADO_NUEVO7" ];
        then 
            echo "ES FERIADO"
        fi
fi
FERIADO_3="10/12/$Y"
FERIADO_DIA3=$(date -d "$FERIADO_3" +'%A')

if [ "$FERIADO_DIA3" == "TUESDAY" ];
    then 
    FERIADO_NUEVO8="$(date --date "$FERIADO_3 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO8" ];
        then 
            echo "ES FERIADO."
        fi
fi
if [ "$FERIADO_DIA3" == "WEDNESDAY" ];
    then
    FERIADO_NUEVO9="$(date --date="$FERIADO_3 -9days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO9" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA3" == "THURSDAY" ];
    then 
    FERIADO_NUEVO10="$(date --date="$FERIADO_3 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO10" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA3" == "FRIDAY" ];
    then 
    FERIADO_NUEVO11="$(date --date="$FERIADO_3 +3days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO11" ];
        then 
            echo "ES FERIADO"
        fi
fi
FERIADO_4="11/20/$Y"
FERIADO_DIA4=$(date -d "$FERIADO_4" +'%A')

if [ "$FERIADO_DIA4" == "TUESDAY" ];
    then 
    FERIADO_NUEVO12="$(date --date="$FERIADO_4 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO12" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA4" == "WEDNESDAY" ];
    then
    FERIADO_NUEVO13="$(date --date="$FERIADO_4 -9days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO13" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA4" == "THURSDAY" ];
    then 
    FERIADO_NUEVO14="$(date --date="$FERIADO_4 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO14" ];
        then 
            echo "ES FERIADO"
        fi
fi
if [ "$FERIADO_DIA4" == "FRIDAY" ];
    then 
    FERIANO_NUEVO15="$(date --date="$FERIADO_4 +3days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERIADO_NUEVO15" ];
        then 
            echo "FERIADO"
        fi
fi
if [ "$DATE" == "01/01/$Y" ];
then
    echo "AÑO NUEVO!!!!!!!!!!!!!!!!!!!!!"
fi

if [[ "$DATE" == "02/15/$Y" || $DATE == "02/16/$Y" ]];
then
    echo "CARNAVAL!"
fi

if [ "$DATE" == "03/24/$Y" ];
then
    echo "FERIADO"
fi
if [ "$DATE" == "04/02/$Y" ];
then
    echo "FERIADO: MALVINAS. "
fi
if [ "$DATE" == "05/01/$Y" ];
then
    echo "DIA DEL TRABAJADOR" 
fi
if [ "$DATE" == "05/25/$Y" ];
then
    echo "REVOLUCION DE MAYO"
fi
if [ "$DATE" == "06/20/$Y" ];
then
    echo "FERIADO"
fi
if [ "$DATE" == "07/09/$Y" ];
then
    echo "DIA DE LA INDEPENDENCIA"
fi
if [ "$DATE" == "12/25/$Y" ];
then
    echo "NAVIDAD"
fi
}

esLaborable "$DATE"
exit 0;
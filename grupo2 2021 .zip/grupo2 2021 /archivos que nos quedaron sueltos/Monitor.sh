#!/bin/bash

        if pgrep -x "sshd"
        then
        echo "El ssh se encuentra en funcionamiento"
        else
        exec echo "El ssh no está activo" | mail -s "ADVERTENCIA  !" root
        echo "El ssh no está activo "
        fi
        
        



        if pgrep -x "apache2" > /dev/null
        then
        echo "apache 2 se encuentra en funcionamiento"
        else

        exec echo "apache2 no esta activo" | mail -s "ADVERTENCIA  !" root
        echo "mysql se encuentra desactivado "
        fi
        
        


        
        if pgrep -x "mysqld"
        then
        echo "mysql está funcionando"
        else
        exec echo "mysql esta desactivado " | mail -s "ADVERTENCIA  !" root
        echo "mysql esta desactivado"
        fi

exit 1;
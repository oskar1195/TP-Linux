#!/bin/bash 
#etc var log

while getopts ":h" option; do
   case $option in
      h) 
         echo -e "este script utiliza el formato "./backup.sh /origen /destino" para realizar backups \nsin parametros realiza un backup de etc var y log"
         exit;;
      *) 
         echo "Error: Invalid option"
         exit;;
   esac
done

TIME=$(date +"%y%m%d")
TIME2=$(date +"%y%m%d%H%M%S")
TIME3=$(date +"[%H:%M:%S]")
log="backup inicio $TIME3"

if [ $# = 2 ]
then	
	
	if [ -d $1 ] && [ -d $2 ]
	then
	TIME3=$(date +"[%H:%M:%S]")
	log="$log\n$TIME3 carpetas detectadas exitosamente... iniciando copiado"  
	SRCDIRP=$1                    
	DESDIRP=$2 
	FILENAMEP=$SRCDIRP_backup-$TIME.tar.gz
	
	tar -cpzf $DESDIRP/$FILENAMEP $SRCDIRP
	
	TIME3=$(date +"[%H:%M:%S]")
	log="$log\n$TIME3 Copia realizada exitosamente \nfin del programa..."
	echo "comando realizado con exito"
	else
	
	TIME3=$(date +"[%H:%M:%S]")
	log="$log\n$TIME3 Carpetas no detectadas \nfin del programa"
	echo"la o las carpetas seleccionadas no existen"
	fi
	 
echo -e $log | mail -s "backup-$TIME2" root

exec echo -e $log > /log/backup-log-$TIME2.txt

elif [ $# = 0 ]
then
	
	FILENAME1=etc_backup-$TIME.tar.gz    
	SRCDIR1=/etc                    
	DESDIR1=/lv_backup 
           
	FILENAME2=var_backup-$TIME.tar.gz    
	SRCDIR2=/var                    
	DESDIR2=/lv_backup
 
            
	FILENAME3=log_backup-$TIME.tar.gz    
	SRCDIR3=/log                    
	DESDIR3=/lv_backup

	#lv_www lv_db

            
	FILENAME4=db_backup-$TIME.tar.gz    
	SRCDIR4=/lv_db                    
	DESDIR4=/lv_backup

          
	FILENAME5=www_backup-$TIME.tar.gz    
	SRCDIR5=/lv_www                    
	DESDIR5=/lv_backup     		 

	hora=$(date +%H)
	day=$(date +%A)
	
	TIME3=$(date +"[%H:%M:%S]")
	log=$log"\n$TIME3 inicializando backup automatico >> /log/backuplog-$TIME2.txt"
		
	if mountpoint -q -- "/lv_backup";
		then
		
		TIME3=$(date +"[%H:%M:%S]")
		log=$log"\n$TIME3 El disco de backup fue detectado correctamente, inicializando proceso de copiado"
		
		if [ "$day" = "Sunday" ] && [ "$hora" = "23" ]
		then	
			if mountpoint -q -- "$SRCDIR5";
			then
			
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR5 detectada exitosamente..."
			

  			tar -cpzf $DESDIR5/$FILENAME5 $SRCDIR5
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR5 copia finalizada exitosamente..."
  			
			
			else
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR5 no ha sido detectado por lo tanto no se copio"
			echo '%s\n' "$SRCDIR5 no esta montado"

			fi
			
			if mountpoint -q -- "$SRCDIR4";
			then
			
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR4 detectada exitosamente..."
  			
			tar -cpzf $DESDIR4/$FILENAME4 $SRCDIR4
			
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR4 copia finalizada..."
  						
			else
			
			echo '%s\n' "$SRCDIR4 no esta montado"
			fi
	
		else	
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 inicializando copias de $SRCDIR1 $SRCDIR2 $SRCDIR3..."
  			
  			tar -cpzf $DESDIR1/$FILENAME1 $SRCDIR1
			
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR1 copia finalizada exitosamente..."
  						
  			tar -cpzf $DESDIR2/$FILENAME2 $SRCDIR2
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR2 copia finalizada exitosamente..."			

  			tar -cpzf $DESDIR3/$FILENAME3 $SRCDIR3
			TIME3=$(date +"[%H:%M:%S]")
			log="$log\n$TIME3 $SRCDIR3 copia finalizada exitosamente..."
		fi
	else	
		TIME3=$(date +"[%H:%M:%S]")
		log="$log\n$TIME3 unidad de backup no encontrada..."
		echo "no se encuentra la unidad de backup"
		
	fi
echo -e $log | mail -s "backup-$TIME2" root

exec echo -e $log > /log/backup-log-$TIME2.txt


else	
	echo"parametros erroneos"
fi

exit 1;